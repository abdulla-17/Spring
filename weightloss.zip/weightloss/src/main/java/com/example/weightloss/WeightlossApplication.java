package com.example.weightloss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeightlossApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeightlossApplication.class, args);
	}

}
