package com.example.weightloss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeightlossApplicationTests {

	@Test
	void contextLoads() {
	}

}
